#!/bin/bash

echo "Running tests for the sample project..."

# Run tests using pytest
pytest tests/